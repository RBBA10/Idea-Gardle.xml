Hello World!

This is my very first android project!

Glad you visited me.

# Changelog

v0.0.1
- Adding basic global component
- Adding basic global style
- Adding database local functionality
